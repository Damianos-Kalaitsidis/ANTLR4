class Person:
	def __init__(self, pid, born):
		self.pid = pid
		self.born = born
		