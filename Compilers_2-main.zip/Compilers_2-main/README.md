A compiler for simplepp (simple-python-python) that translates code into C
